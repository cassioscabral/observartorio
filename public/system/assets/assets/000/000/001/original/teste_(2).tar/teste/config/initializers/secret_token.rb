# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Teste::Application.config.secret_token = '8bc53b0aa39baae3267b906038574efb8a8024c13edfa1f15d5cf2abea7eba00d8bf2c0b8e138f7043b3df7607ceeb0dddbcd2f90d0db6711d845cbcce248f72'
